import random
import time

random.seed(time.time())


def main():
    val = input(f'Welcome challengers! To get a secret reward, you will have to solve 10 one-liner questions. Are you ready [Y/N]? \n> ')
    print()
    time.sleep(1)

    if val == 'Y':
        correct = 0

        question = ['assert __import__(\'base64\').b64encode(input().encode()) == b\'Y29jYXk=\'',
                    'assert __import__(\'pwn\').xor(input().encode(), b\'BKISC\') == b\'/*:2.7%,\'',
                    'assert int(input().encode().hex(), 16) == 1751214132',
                    'assert bin(int.from_bytes(input().encode(), byteorder=\'little\'))[2:] == \'11011110110100101001100\'',
                    'assert input()[::-1] == \'ikamuzUiuQ\'',
                    'assert [i for i in input().encode()] == [70, 97, 122, 101, 67, 84]',
                    'assert [i ^ 0x69 ^ 0x13 ^ 0x37 for i in input().encode()] == [35, 37, 44, 57, 41, 44, 35, 42, 124, 116, 125, 124]',
                    'assert \'\'.join([s[i] for i in range(0, 11, 2)] + [s[i] for i in range(1, 11, 2)][::-1]) == \'hagELREARno\'',
                    'assert __import__(\'hashlib\').sha256(input().encode()).hexdigest() == \'dbcae28bd63862314d62462f221523e5fb9225974317cf43f342633a9d5c2c89\'',
                    'assert __import__(\'hashlib\').sha512(input().encode()).hexdigest() == \'64c092f1ad869ea15f017d9028eca9b947d3f2fa5c205747992d5eaeb36e463bca53facfbb50c3669653b8272071b47207e7059669169e3e57c3446b8ac36218\'']

        ques_count = len(question)

        result = ['cocay', 'masamune', 'hah4', 'Lio', 'QuiUzumaki', 'FazeCT', 'nhatdang1901', 'hoangREALER', 'hacao', 'Onirique']

        assert len(result) == ques_count

        ls = [[question[i]] + [result[i]] for i in range(ques_count)]
        random.shuffle(ls)

        for i in range(ques_count):
            print('Question {}:\n'.format(i + 1) + ls[i][0])
            s = input(f"> ")
            if s == ls[i][1]:
                correct += 1
            print()

        time.sleep(1)
        if correct == ques_count:
            print("Great job, the flag is: BKISC{th0s3_ar3_th3_4uth0rs_0f_th1s_CTF_als0_w3lc0m3_t0_th3_w0rld_0f_r3v!!!}")
        else:
            if correct == 0:
                print("Hmmge...")
            else:
                print("Keep going, you got {} corrects so far!".format(correct))
    elif val == 'N':
        print('Well, probably we will meet again next time...')
    else:
        print('Reading the instructions carefully is also very crucial in solving CTF challenges...')


if __name__ == "__main__":
    main()

